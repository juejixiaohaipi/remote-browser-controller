// RELOAD TEST 2026-03-26-1336-CONTENT-SCRIPT-RETRY
// Handles WebSocket connection to control server and routes commands to content scripts

// ============= Helpers =============

/** Get bounding rect of a DOM element by selector (used by captcha.screenshot) */
function getElementScreenshotInline(selector) {
  const el = document.querySelector(selector);
  if (!el) return null;
  const r = el.getBoundingClientRect();
  return {
    x: Math.round(r.left),
    y: Math.round(r.top),
    w: Math.round(r.width),
    h: Math.round(r.height),
    centerX: Math.round(r.left + r.width / 2),
    centerY: Math.round(r.top + r.height / 2),
  };
}

/** Sleep helper */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============= MV3 SW Keep-Alive =============
// Chrome MV3 kills idle SW after ~30s.
// Strategy: don't over-activate the SW, let it idle naturally.
// On SW restart (onStartup), recover the connection.

chrome.runtime.onStartup.addListener(() => {
  console.log('[RBC] SW restarted — recovering connection');
  if (conn) conn.loadConfig();
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('[RBC] Extension installed/upgraded');
});

// ============= Connection Manager (Offscreen-based for MV3) =============
// WebSocket lives in offscreen.html — survives service worker kills
// Background SW acts as message router

class RBCConnectionManager {
  constructor() {
    this.ws = null;
    this.sessionId = null;
    this.connected = false;
    this.reconnectAttempts = 0;
    this.reconnectDelay = 1000;
    this.maxReconnectAttempts = 10;
    this.heartbeatTimer = null;
    this.config = { serverUrl: '', token: '', deviceName: '', deviceId: '', autoConnect: false };
    this.status = 'disconnected';
    this.statusText = 'Not connected';
    this._commandWaiters = new Map();
    this._offscreenReady = false;

    // Route messages from content scripts and popup
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      this._handleCommand(msg.type, msg.id, msg.method, msg.params, sendResponse);
      return true;
    });
  }

  async loadConfig() {
    const result = await chrome.storage.local.get(['serverUrl','token','deviceName','autoConnect','deviceId']);
    let deviceId = result.deviceId;
    if (!deviceId) { deviceId = crypto.randomUUID(); await chrome.storage.local.set({ deviceId }); }
    this.config = { serverUrl: result.serverUrl||'', token: result.token||'', deviceName: result.deviceName||'', deviceId, autoConnect: result.autoConnect||false };
    if (this.config.autoConnect && this.config.serverUrl && this.config.token) this.connect();
  }

  async saveConfig(newConfig) {
    Object.assign(this.config, newConfig);
    await chrome.storage.local.set({ serverUrl: this.config.serverUrl, token: this.config.token, deviceName: this.config.deviceName, deviceId: this.config.deviceId, autoConnect: this.config.autoConnect });
  }

  getDeviceId() { return this.config.deviceId || chrome.runtime.id; }

  async connect() {
    if (!this.config.serverUrl || !this.config.token) { this._updateStatus('error', 'Server or token not configured'); return; }
    this._updateStatus('connecting', 'Connecting...');
    await this._connectDirect();
  }

  async _connectDirect() {
    // Direct WebSocket — same as original, survives SW via keep-alive
    if (this.ws) { this.ws.close(); this.ws = null; }
    try {
      this.ws = new WebSocket(this.config.serverUrl);
    } catch (err) {
      this._updateStatus('error', 'Connection failed: ' + err.message);
      return;
    }
    this.ws.onopen = () => {
      this.connected = true; this.reconnectAttempts = 0;
      this._updateStatus('connected', 'Connected');
      this._authenticate(); this._startHeartbeat();
    };
    this.ws.onmessage = (e) => { try { this._handleMessage(JSON.parse(e.data)); } catch {} };
    this.ws.onclose = (e) => {
      this.connected = false; this.sessionId = null; this._stopHeartbeat();
      this._updateStatus('disconnected', `Connection closed (${e.code})`);
      this._scheduleReconnect();
    };
    this.ws.onerror = () => {
      this._updateStatus('error', 'Connection error');
      this.ws?.close();
    };
  }

  _scheduleReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      this._updateStatus('error', 'Max reconnect attempts reached');
      return;
    }
    const delay = Math.max(5000, Math.min(this.reconnectDelay * Math.pow(2, this.reconnectAttempts), 30000));
    this.reconnectAttempts++;
    this._updateStatus('reconnecting', `Reconnecting in ${Math.round(delay/1000)}s (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
    setTimeout(() => { this.connect(); }, delay);
  }

  _authenticate() {
    this._send({
      type: 'auth',
      token: this.config.token,
      deviceId: this.getDeviceId(),
      deviceName: this.config.deviceName || `Chrome-${this.getDeviceId().slice(0,8)}`,
      browserType: 'chrome',
      tags: ['chrome-extension']
    });
  }

  _handleMessage(msg) {
    switch (msg.type) {
      case 'auth_ok':
        this.sessionId = msg.sessionId;
        this._updateStatus('connected', `Connected (${msg.sessionId?.slice(0,8)})`);
        this._broadcast({ type: 'connected', sessionId: msg.sessionId });
        break;
      case 'auth_error':
        this._updateStatus('error', `Auth failed: ${msg.error}`);
        break;
      case 'pong': break;
      case 'event': this._handleEvent(msg.event, msg.data); break;
      case 'command_response': this._handleCommandResponse(msg.id, msg.result, msg.error); break;
      default:
        if (msg.type?.startsWith('tab_')) {
          const tabId = msg.type.split('_')[1];
          this._sendToTab(tabId, msg.method, msg.params).catch(() => {});
        }
    }
  }

  _handleEvent(event, data) {
    if (this._eventWaiters?.[event]) {
      clearTimeout(this._eventWaiters[event].timeout);
      this._eventWaiters[event].resolve(data);
      delete this._eventWaiters[event];
    }
  }

  disconnect() {
    this._stopHeartbeat();
    this.sessionId = null;
    this.connected = false;
    this.reconnectAttempts = 0;
    if (this.ws) { try { this.ws.close(1000, 'User disconnect'); } catch {} this.ws = null; }
    this._broadcast({ type: 'status', status: 'disconnected', text: 'Disconnected' });
    // No offscreen — direct WS mode
  }

  _handleCommandResponse(id, result, error) {
    const pending = this._commandWaiters.get(id);
    if (pending) { clearTimeout(pending.timeout); this._commandWaiters.delete(id); pending.sendResponse({ id, result, error }); }
  }

  // ── Send via WebSocket ────────────────────────────────────────────────────

  _send(data) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
      return true;
    }
    return false;
  }

  // ── Status ──────────────────────────────────────────────────────────────────

  _updateStatus(status, text) {
    this.status = status; this.statusText = text;
    this._broadcast({ type: 'status', status, text });
  }

  _broadcast(message) {
    chrome.tabs.query({}, (tabs) => { for (const tab of tabs) { if (tab.id) chrome.tabs.sendMessage(tab.id, message).catch(() => {}); } });
    chrome.runtime.sendMessage(message).catch(() => {});
  }

  // ── Heartbeat ───────────────────────────────────────────────────────────────

  _startHeartbeat() {
    this.heartbeatTimer = setInterval(() => { if (this.connected) this._send({ type: 'ping' }); }, 30000);
  }

  _stopHeartbeat() {
    if (this.heartbeatTimer) { clearInterval(this.heartbeatTimer); this.heartbeatTimer = null; }
  }

  // ── Tab helpers ─────────────────────────────────────────────────────────────

  _getActiveTab() { return new Promise((resolve) => { chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs[0]||null)); }); }

  _sendToTab(tabId, method, params) {
    return chrome.tabs.sendMessage(tabId, { type: method, params });
  }

  // ── Command routing ────────────────────────────────────────────────────────

  _handleCommand(id, method, params, sendResponse) {
    const timeout = setTimeout(() => { this._commandWaiters.delete(id); sendResponse({ id, error: { code: -32000, message: `Timeout: ${method}` } }); }, 60000);
    this._commandWaiters.set(id, { method, timeout, sendResponse });
    this._send({ type: 'command', id, method, params });
  }

  _handleLocalCommand(method, params, id) {
    switch (method) {
      case 'browser.info': return { id, result: { status: this.status, text: this.statusText } };
      case 'browser.version': return { id, result: { version: chrome.runtime.getManifest().version } };
      default: return false;
    }
  }
}

// ============= Global Instance =============

const conn = new RBCConnectionManager();

// Load config and auto-connect on startup
conn.loadConfig();

// ============= Message Listeners =============

// From popup and content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[RBC] Background received', message.type, message);

  switch (message.type) {
    case 'popup_connect':
      conn.connect();
      sendResponse({ success: true });
      break;

    case 'popup_disconnect':
      conn.disconnect();
      sendResponse({ success: true });
      break;

    case 'popup_status':
      sendResponse({
        status: conn.status,
        config: conn.config,
        sessionId: conn.sessionId,
        deviceName: conn.config?.deviceName || '',
        deviceId: conn.getDeviceId(),
      });
      break;

    case 'popup_save_config':
      conn.saveConfig(message.config).then(() => sendResponse({ success: true }));
      return true; // async

    case 'popup_get_default_token':
      // This triggers the background to respond with the token
      sendResponse({ token: conn.config.token });
      break;

    case 'content_dialog':
      conn._send({
        type: 'event',
        event: 'dialog.opened',
        data: { dialogType: message.dialogType, message: message.message }
      });
      sendResponse({ received: true });
      break;

    case 'content_page_loaded':
      conn._send({
        type: 'event',
        event: 'page.loaded',
        data: { url: message.url, title: message.title }
      });
      sendResponse({ received: true });
      break;

    case 'content_screenshot':
      conn._send({
        type: 'event',
        event: 'screenshot.captured',
        data: { screenshot: message.screenshot }
      });
      sendResponse({ received: true });
      break;

    case 'capture_visible_tab': {
      // Handle screenshot request from content script
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.captureVisibleTab(tabs[0].windowId, { format: 'png' }, (dataUrl) => {
            sendResponse(dataUrl);
          });
        } else {
          sendResponse(null);
        }
      });
      return true; // async
    }

    default:
      sendResponse({ error: 'Unknown message type' });
  }

  return true;
});

// ============= Tab Observers =============

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    conn._send({
      type: 'event',
      event: 'page.loaded',
      data: { url: tab.url, title: tab.title, tabId }
    });
  }
});

// Broadcast URL changes to popup when active tab changes
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab?.url && tab.url.startsWith('http')) {
      conn._broadcast({ url: tab.url, title: tab.title });
    }
  } catch { /* ignore */ }
});

// Also broadcast on navigation
chrome.webNavigation?.onCompleted?.addListener((details) => {
  if (details.frameId === 0 && details.url.startsWith('http')) {
    conn._broadcast({ url: details.url });
  }
});

// ============= Downloads Observer ================================

chrome.downloads.onCreated.addListener((downloadItem) => {
  conn._send({
    type: 'event',
    event: 'download.started',
    data: {
      id: downloadItem.id,
      filename: downloadItem.filename,
      url: downloadItem.url,
      mimeType: downloadItem.mime,
      state: downloadItem.state,
      startedAt: downloadItem.startTime
    }
  });
});

chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state && delta.state.current === 'complete') {
    conn._send({
      type: 'event',
      event: 'download.complete',
      data: {
        id: delta.id,
        filename: delta.filename?.current,
        state: delta.state.current
      }
    });
  }
});

console.log('[RBC] Background service worker initialized');
