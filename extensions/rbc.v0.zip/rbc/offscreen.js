// offscreen.js — WebSocket lives here, survives service worker kills
// Background SW talks to this via chrome.runtime.sendMessage

let ws = null;
let reconnectAttempts = 0;
const RECONNECT_BASE = 5000;
const RECONNECT_MAX = 30000;

function sendToBg(type, data = {}) {
  chrome.runtime.sendMessage({ source: 'offscreen', type, ...data }).catch(() => {});
}

function scheduleReconnect() {
  reconnectAttempts++;
  const delay = Math.min(RECONNECT_BASE * Math.pow(2, reconnectAttempts - 1), RECONNECT_MAX);
  sendToBg('reconnecting', { delay, attempt: reconnectAttempts });
  setTimeout(() => connect.apply(null, savedConfig), delay);
}

function connect(serverUrl, token, deviceId, deviceName) {
  if (ws) { ws.close(); ws = null; }
  try {
    ws = new WebSocket(serverUrl);
  } catch (err) {
    sendToBg('error', { message: err.message });
    scheduleReconnect();
    return;
  }

  ws.onopen = () => {
    reconnectAttempts = 0;
    sendToBg('connected', {});
    ws.send(JSON.stringify({
      type: 'auth', token, deviceId,
      deviceName: deviceName || `Chrome-${deviceId?.slice(0, 8)}`,
      browserType: 'chrome', tags: ['chrome-extension', 'offscreen']
    }));
  };

  ws.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data);
      sendToBg('message', { msg });
    } catch {}
  };

  ws.onclose = (event) => {
    sendToBg('disconnected', { code: event.code });
    ws = null;
    scheduleReconnect();
  };

  ws.onerror = () => {
    sendToBg('error', { message: 'WebSocket error' });
    ws?.close();
  };
}

let savedConfig = null;

// Handle messages from background SW
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.target !== 'offscreen') return false;
  switch (msg.action) {
    case 'start':
      savedConfig = [msg.serverUrl, msg.token, msg.deviceId, msg.deviceName];
      reconnectAttempts = 0;
      connect(msg.serverUrl, msg.token, msg.deviceId, msg.deviceName);
      break;
    case 'stop':
      reconnectAttempts = 9999; // prevent reconnect
      ws?.close();
      break;
    case 'send':
      if (ws?.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(msg.data));
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: 'Not connected' });
      }
      break;
    case 'status':
      sendResponse({ connected: ws?.readyState === WebSocket.OPEN });
      break;
  }
  return true;
});
